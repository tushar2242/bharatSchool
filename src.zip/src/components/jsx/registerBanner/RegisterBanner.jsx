import React from 'react';
import { NavLink } from 'react-router-dom';
import SearchIcon from '@mui/icons-material/Search';


export default class RegisterBanner extends React.Component {
    render() {
        return (
            <>
                <div className="banner-bg-1">
                    <div className="banner-txt-1">
                        <h1>Add Your School with us</h1>
                        <div className="bannerInputBox">
                            <NavLink to="/register" className="bannerBtn">Register Your School </NavLink>
                        </div>
                    </div>

                </div>
            </>
        )
    }
}


