import React from 'react';

import img1 from '../../images/info/1.png';
import img2 from '../../images/info/2.png';
import img3 from '../../images/info/3.png';
import img4 from '../../images/info/4.png';

export default class AboutSchool extends React.Component {
    render() {
        return (
            <>
                <div className="container p-4">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="row">
                                <div className="col-md-6 mt-3">
                                    <StudentCard
                                        img={img1}
                                    />
                                </div>
                                <div className="col-md-6 mt-3">
                                    <StudentCard
                                        img={img2}
                                    />
                                </div>
                                <div className="col-md-6 mt-3">
                                    <StudentCard
                                        img={img3}
                                    />
                                </div>
                                <div className="col-md-6 mt-3">
                                    <StudentCard
                                        img={img4}
                                    />
                                </div>
                            </div>

                        </div>

                        <div className="col-md-6 mt-3">
                            <SchoolDetails />
                        </div>
                    </div>
                </div>

            </>
        )
    }
}

class StudentCard extends React.Component {
    render() {
        const { img } = this.props;

        return (
            <>
                <div className="center">
                    <div className="article-card">
                        <div className="content">
                            <p className="date">Jan 1, 2022</p>
                            <p className="title">Article Title Goes Here</p>
                        </div>
                        <img src={img} alt="article-cover" />
                    </div>
                </div>

            </>
        )
    }
}

class SchoolDetails extends React.Component {
    render() {
        return (
            <>
                <div>
                    <h2 className="school-heading mb-3">Who are we and why us?</h2>
                    <p className="sc-details-para">Welcome to School Dekho,Best School near me,Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in kolkata, Best schools in kolkata according to area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.</p>
                    <p className="sc-details-para">Welcome to School Dekho,Best School near me,Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in kolkata, Best schools in kolkata according to area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.</p>
                </div>

            </>
        )
    }
}