import React from 'react';
import NavBar from '../navbar/NavBar';

import { TweenMax } from "gsap";
import Banner from '../banner/Banner';
// import SchoolCard from './SchoolCard';
import SchoolCardCarousel from '../recommendSchool/SchoolCardCarousel';
import Testimonial from '../testimonial/Testimonial';
import RegisterBanner from '../registerBanner/RegisterBanner';
import AnimatedCard from '../recentArticle/AnimatedCard';
import Footer from '../footer/Footer';
// import Gallery from './Gallery';
import AboutSchool from '../aboutUs/AboutSchool';
import NewsCard from '../inNews/NewsCard';
import CounterCard from '../counter/CounterCard';
// import {reducer} from './redux/reducer';
// import { createStore } from 'redux';
// import Counter from './redux/Counter';




export default class Home extends React.Component {

  constructor(props) {
    super(props);

    this.componentDidMount = this.componentDidMount.bind(this);
  }

  componentDidMount() {

    TweenMax.fromTo('.shadow', 0.7, { y: -70, opacity: 0 }, { y: 0, opacity: 1 });

    // const accessToken = localStorage.getItem('accessToken');
    // console.log(accessToken);
    // const userId = localStorage.getItem('userId');
    // console.log(userId);

  }



  render() {
    return (
      <>
        {/* <Counter /> */}
        <NavBar />

        <Banner />

        <SchoolCardCarousel />

        <AboutSchool />

        <RegisterBanner />

        <CounterCard />

        <Testimonial />

        <AnimatedCard />

        <NewsCard />

        <Footer />



      </>
    );
  }
}

