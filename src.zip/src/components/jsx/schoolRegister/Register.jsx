import React from 'react';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';

import axios from 'axios';
import Chip from '@mui/material/Chip';
import Autocomplete from '@mui/material/Autocomplete';
import Stack from '@mui/material/Stack';




export default class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            schName: '',
            schAddress: '',
            contactNo: '+91 ',
            emailId: '',
            schType: '',
            board: '',
            type: '',
            coType: '',
            medium: '',
            eligibility: '',
            subject: '',
            school_description: '',
            thought: '',
            contactName: '',
            contactNumber: '+91 ',
            rmId: '',

            subjects: ['Inception'],
        }
        this.handleSubmit = this.handleSubmit.bind(this)
        this.handleSelect = this.handleSelect.bind(this)
    }


    handleSelect(value) {
        this.setState({ subjects: value })
    }

    handleSubmit(e) {
        e.preventDefault();
        let { schName, schAddress, contactNo, emailId, schType, board, type, coType, medium, eligibility, subjects, contactName, contactNumber, rmId, thought, school_description } = this.state;
        axios.post('http://localhost:6003/school/insert', {
            name: schName,
            address: schAddress,
            officeally_number: contactNo,
            officelly_email: emailId,
            schType: schType,
            board: board,
            type: type,
            subjects: subjects,
            medium: medium,
            eligibility: eligibility,
            principle_thought: thought,
            school_description: school_description,
            contactInfo: {
                name: contactName,
                number: contactNumber,
                rmId: rmId,
            }
        })
            .then(res => console.log(res))
            .catch(res => console.log(res.message))
    }


    render() {
        const { schName, schAddress, contactNo, emailId, schType, board, type, coType, medium, eligibility, school_description, contactName, contactNumber, rmId, thought } = this.state;
        return (
            <>
                <div className="register-box">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="bg-white shadow-sm p-4">
                                    <h4 className="reg-heading"><b>School Information</b></h4>
                                    <p className="borderline"></p>
                                    <form onSubmit={this.handleSubmit}>
                                        <TextField fullWidth id="school-name" label="School Name" variant="standard" margin="normal" className="label-font" onChange={(e) => this.setState({ schName: e.target.value })} value={schName} />
                                        <TextField fullWidth id="school-address" label="Address Of The School" variant="standard" margin="normal" onChange={(e) => this.setState({ schAddress: e.target.value })} value={schAddress} />
                                        <div className="row">
                                            <div className="col-md-6">
                                                <TextField fullWidth id="school-contact" label="Official Contact Number" variant="standard" margin="normal" onChange={(e) => this.setState({ contactNo: e.target.value })} value={contactNo} />
                                            </div>
                                            <div className="col-md-6">
                                                <TextField fullWidth id="school-emailId" label="Official Email Id" variant="standard" margin="normal" onChange={(e) => this.setState({ emailId: e.target.value })} value={emailId} />
                                            </div>
                                            <div className="col-md-6">
                                                <FormControl variant="standard" fullWidth margin="normal">
                                                    <InputLabel id="school-type">School Type</InputLabel>
                                                    <Select
                                                        labelId="school-type"
                                                        id="select-school-type"
                                                        onChange={(e) => this.setState({ schType: e.target.value })}
                                                        value={schType}
                                                    >
                                                        <MenuItem value="Govt.">Govt.</MenuItem>
                                                        <MenuItem value="Private">Private</MenuItem>
                                                        <MenuItem value="Semi-Govt.">Semi-Govt.</MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </div>
                                            <div className="col-md-6">
                                                <FormControl variant="standard" fullWidth margin="normal">
                                                    <InputLabel id="school-board">Board</InputLabel>
                                                    <Select
                                                        labelId="school-board"
                                                        id="select-school-board"
                                                        onChange={(e) => this.setState({ board: e.target.value })}
                                                        value={board}
                                                    >
                                                        <MenuItem value="CBSE">CBSE</MenuItem>
                                                        <MenuItem value="BSER">BSER</MenuItem>
                                                        <MenuItem value="CISCE">CISCE</MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </div>
                                            <div className="col-md-6">
                                                <FormControl variant="standard" fullWidth margin="normal">
                                                    <InputLabel id="bg-co-type">Type</InputLabel>
                                                    <Select
                                                        labelId="type"
                                                        id="select-bg-co-type"
                                                        onChange={(e) => this.setState({ type: e.target.value })}
                                                        value={type}
                                                    >
                                                        <MenuItem value="Boys">Boys</MenuItem>
                                                        <MenuItem value="Girls">Girls</MenuItem>
                                                        <MenuItem value="Girls">Co-Ed</MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </div>
                                            <div className="col-md-6">
                                                <FormControl variant="standard" fullWidth margin="normal">
                                                    <InputLabel id="school-medium">Medium</InputLabel>
                                                    <Select
                                                        labelId="school-medium"
                                                        id="select-school-medium"
                                                        onChange={(e) => this.setState({ medium: e.target.value })}
                                                        value={medium}
                                                    >
                                                        <MenuItem value="English" >English</MenuItem>
                                                        <MenuItem value="Hindi">Hindi</MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </div>
                                            <div className="col-md-6">
                                                <FormControl variant="standard" fullWidth margin="normal">
                                                    <InputLabel id="class-criteria">Eligibility Criteria</InputLabel>
                                                    <Select
                                                        labelId="class-criteria"
                                                        id="select-class-criteria"
                                                        onChange={(e) => this.setState({ eligibility: e.target.value })}
                                                        value={eligibility}
                                                    >
                                                        <MenuItem value="5-10 yrs">5-10 yrs</MenuItem>
                                                        <MenuItem value="10-15 yrs">10-15yrs</MenuItem>
                                                        <MenuItem value="15-20 yrs">15-20 yrs</MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </div>
                                            <div className="col-md-6"></div>

                                            {/* <ToDoList /> */}
                                            <Tags
                                                handleSelect1={this.handleSelect}
                                            />

                                        </div>
                                        <TextField fullWidth id="description" label="School Description" variant="outlined" margin="normal" multiline
                                            rows={5}
                                            onChange={(e) => this.setState({ school_description: e.target.value })}
                                            value={school_description}
                                        />
                                        <TextField fullWidth id="thought" label="Principle Thought" variant="outlined" margin="normal" multiline
                                            rows={5}
                                            onChange={(e) => this.setState({ thought: e.target.value })}
                                            value={thought}
                                        />


                                        <h4 className="reg-heading mt-4"><b>Contact Information</b></h4>
                                        <p className="borderline"></p>
                                        <div className="row">
                                            <div className="col-md-6">
                                                <TextField fullWidth id="contact-name" label="Name" variant="standard" margin="normal" className="label-font" value={contactName} onChange={(e) => {
                                                    this.setState({ contactName: e.target.value })
                                                }} />
                                            </div>

                                            <div className="col-md-6">
                                                <TextField fullWidth id="contact-number" label="Mobile Number" variant="standard" margin="normal" className="label-font" value={contactNumber} onChange={(e) => {
                                                    this.setState({ contactNumber: e.target.value })
                                                }} />
                                            </div>
                                            <div className="col-md-6">
                                                <FormControl variant="standard" fullWidth margin="normal">
                                                    <InputLabel id="rm-id">R.M ID</InputLabel>
                                                    <Select
                                                        labelId="rm-id"
                                                        id="select-rm-id"
                                                        value={rmId} onChange={(e) => {
                                                            this.setState({ rmId: e.target.value })
                                                        }}
                                                    >
                                                        <MenuItem value="578904">578904</MenuItem>
                                                        <MenuItem value="578905">578905</MenuItem>
                                                        <MenuItem value="578906">578906</MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </div>
                                        </div>
                                        <Button variant="contained" className="submit-btn" type='submit'>
                                            Submit
                                        </Button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}




function Tags(props) {

    const { handleSelect1 } = props;

    function handleSelect(event, value) {

        handleSelect1(value)
    }


    return (
        <>
            <Stack spacing={3} sx={{ width: 500 }} className='stackInfo'>
                <Autocomplete
                    multiple
                    id="tags-filled"
                    options={top100Films.map((option) => option.title)}
                    defaultValue={[top100Films[13].title]}
                    freeSolo
                    onChange={handleSelect}
                    renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                            <Chip variant="outlined" label={option} {...getTagProps({ index })} />
                        ))
                    }
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            variant="filled"
                            label="Select Subjects"
                            placeholder="Subjects"
                        />
                    )}
                />
            </Stack>
        </>
    );
}

// Top 100 films as rated by IMDb users. 

const top100Films = [
    { title: 'The Shawshank Redemption', year: 1994 },
    { title: 'The Godfather', year: 1972 },
    { title: 'The Godfather: Part II', year: 1974 },
    { title: 'The Dark Knight', year: 2008 },
    { title: '12 Angry Men', year: 1957 },
    { title: "Schindler's List", year: 1993 },
    { title: 'Pulp Fiction', year: 1994 },
    {
        title: 'The Lord of the Rings: The Return of the King',
        year: 2003,
    },
    { title: 'The Good, the Bad and the Ugly', year: 1966 },
    { title: 'Fight Club', year: 1999 },
    {
        title: 'The Lord of the Rings: The Fellowship of the Ring',
        year: 2001,
    },
    {
        title: 'Star Wars: Episode V - The Empire Strikes Back',
        year: 1980,
    },
    { title: 'Forrest Gump', year: 1994 },
    { title: 'Inception', year: 2010 },
    {
        title: 'The Lord of the Rings: The Two Towers',
        year: 2002,
    },
    { title: "One Flew Over the Cuckoo's Nest", year: 1975 },
    { title: 'Goodfellas', year: 1990 },
    { title: 'The Matrix', year: 1999 },
    { title: 'Seven Samurai', year: 1954 },


];