import React from "react";
import SearchIcon from '@mui/icons-material/Search';
import { Button } from 'react-bootstrap';
import { Navbar } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import TextField from '@mui/material/TextField';
import Container from 'react-bootstrap/Container';
import Login from './Login';
import logo from '../../images/logo2.png';

import { NavDropdown } from 'react-bootstrap';
import AccountIcon from '@mui/icons-material/AccountCircle';
//import axios from "axios";
//import { connect } from "react-redux";
import DehazeIcon from '@mui/icons-material/Widgets';
import store from "../../redux/store";
import { updateValue } from '../../redux/valueAction';


const accessToken = localStorage.getItem('accessToken');
const userId = localStorage.getItem('userId');

//const accessToken = 'adfadsfasd';

class NavBar extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            search: '',
            setLogin: false,
            item: [],
        }
        this.hideLogin = this.hideLogin.bind(this);
        this.componentDidMount = this.componentDidMount.bind(this);
        this.showLogin = this.showLogin.bind(this);
        //this.setProfile = this.setProfile.bind(this);
        //  this.handleClick = this.handleClick.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }


    componentDidMount() {

        //getting search value to redux store  
        const value = store.getState();
        this.setState({ search: value })
        //updating search value to store in redux


        if (accessToken === null) {
            this.showLogin();
        }
        else {
            this.hideLogin()
            // this.setProfile()
            // console.log(accessToken)
        }
    }

    handleSearch(e) {
        this.setState({ search: e.target.value })
        store.dispatch(updateValue(e.target.value));
    }

    authHeader() {
        const user = JSON.parse(localStorage.getItem('userId'));

        if (user && user.accessToken) {
            return { Authorization: 'Bearer ' + user.accessToken };
        } else {
            return {};
        }
    }

    // handleClick() {
    //     const item = { name: 'John', age: 30 };
    //     this.props.setUser(item);
    // }

    hideLogin() {
        this.setState({ setLogin: false })
        // return {
        //     position: 'relative',
        // };
    }

    showLogin() {
        this.setState({ setLogin: true })
        // return {
        //     position: 'fixed',
        // };
    }


    handleLogOut() {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('userId');
        window.location.reload();
    }

    render() {
        const { search, setLogin, item } = this.state;
        return (
            <>
                <Navbar bg="light" expand="lg" className="shadow">
                    <Container>
                        <Navbar.Brand href="/">
                            <img src={logo} alt='schLogo' />
                        </Navbar.Brand>
                        <Navbar.Toggle aria-controls="navbarScroll">
                            <DehazeIcon />
                        </Navbar.Toggle>
                        <Navbar.Collapse id="navbarScroll">

                            <div className="search-bar me-auto ms-auto">

                                <TextField fullWidth id="standard-basic" label="Search Your School" variant="standard" value={search}
                                    onChange={this.handleSearch} required />
                                <Button className="search-button">
                                    <NavLink to='/search'> <SearchIcon /></NavLink>
                                </Button>
                            </div>
                            <div className="registerLogin">
                                <NavLink variant="contained" className="ms-3 register-btn" to="/Register">Register Schools</NavLink>
                                {setLogin ? <Button variant="contained" className="ms-3 login-btn" onClick={this.showLogin}>LOGIN</Button>
                                    : <NavDropdown
                                        id="nav-dropdown-example"
                                        title={<AccountIcon />}
                                        menuVariant="dark"
                                        className='userIcon'
                                    >
                                        {accessToken == null ?

                                            <NavDropdown.Item onClick={this.showLogin}>
                                                Log In
                                            </NavDropdown.Item>

                                            :
                                            <>
                                                <NavLink to='/profile' className='dropdown-item'>
                                                    Profile
                                                </NavLink>
                                                <NavDropdown.Item onClick={this.handleLogOut}>
                                                    Log Out
                                                </NavDropdown.Item>

                                            </>

                                        }
                                    </NavDropdown>

                                }
                            </div>
                        </Navbar.Collapse>

                    </Container>
                </Navbar >


                {setLogin &&
                    <Login
                        setLogin={setLogin}
                        handleLogindisplay={this.hideLogin}
                    />
                }
            </>
        )
    }
}

export default NavBar;



// In navigation we use redux for login popup in update for centralize state variable with navbar component