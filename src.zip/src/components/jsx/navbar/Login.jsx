import React from 'react';
import { TextField, Button } from '@mui/material';
import { NavLink } from 'react-router-dom';
import { TweenMax } from "gsap";
import SignUp from './SignUp';
import ClearIcon from '@mui/icons-material/Clear';
import logo from '../../images/logo1.png';
import axios from 'axios';
import Notification from '../notification/Notification';



export default class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            display: 'login',
            emailError: 'none',
            passwordError: 'none',

            loginError: '',
        }
        this.componentDidMount = this.componentDidMount.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleEmail = this.handleEmail.bind(this);
        this.handlePass = this.handlePass.bind(this);
        this.showSignUp = this.showSignUp.bind(this);
        this.hideSignUp = this.hideSignUp.bind(this);
    }

    handleEmail(e) {
        // let email = e.target.value;
        // let emailcheck = /^[A-Za-z_0-9]{2,}@[A-Za-z]{2,}[.]{1}[A-Za-z.]{1,8}$/gm;
        this.setState({ email: e.target.value });
        // if (!emailcheck.test(email)) {
        //     this.setState({ emailError: 'block' })
        // }
        // else {
        //     this.setState({ emailError: 'none' })
        // }
    }

    handlePass(e) {

        // let password = e.target.value;

        // let passwordcheck = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/gms;
        this.setState({ password: e.target.value });
        // if (!passwordcheck.test(password)) {
        //     this.setState({ passwordError: 'block' })
        // }
        // else {
        //     this.setState({ passwordError: 'none' })
        // }
    }


    handleSubmit(e) {
        e.preventDefault();

        // console.log('fredd')
        axios.post(`http://localhost:6003/user/login`, {
            email: this.state.email,
            password: this.state.password
        })
            .then(res => {
                console.log(res.data)
                localStorage.setItem('accessToken', res.data.data.token);
                localStorage.setItem('userId', res.data.data._id);
                window.location.reload();

            })
            .catch(res => {


            })
    }

    componentDidMount() {
        TweenMax.fromTo('.Loginform', 0.7, { y: -800, opacity: 0 }, { y: 0, opacity: 1 });
        TweenMax.fromTo('.formOuter', 0.85, { x: 800, opacity: 0 }, { x: 0, opacity: 1 });
    }

    showSignUp() {
        this.setState({ display: 'signup' })
    }
    hideSignUp() {
        this.setState({ display: 'login' })
    }
    render() {
        const { email, password, emailError, passwordError, display, loginError } = this.state;
        const { setLogin, handleLogindisplay } = this.props;
        return (
            <>

                <div className="Loginform">
                    {display === 'login' ?
                        <FormContainer
                            email={email}
                            passoword={password}
                            handleEmail={this.handleEmail}
                            handlePass={this.handlePass}
                            handleSubmit={this.handleSubmit}
                            emailError={emailError}
                            passwordError={passwordError}
                            setLogin={setLogin}
                            handleLogindisplay={handleLogindisplay}
                            setShowFunction={this.showSignUp}

                        />
                        : <SignUp
                            hideSignUp={this.hideSignUp}
                            setLogin={setLogin}
                            handleLogindisplay={handleLogindisplay}
                        />
                    }

                    <div className="carouselOuter">
                        <div className="logo">
                            <img src={logo} alt="logo" />
                        </div>
                        <Button type='button login' variant='contained' onClick={this.hideSignUp}>Login</Button>

                        <Button type='button' variant='contained' onClick={this.showSignUp}>Sign Up</Button>
                    </div>
                </div>

            </>
        )
    }
}

class FormContainer extends React.Component {
    render() {

        const { email, password, handleEmail, handlePass, emailError, passwordError, setLogin, handleLogindisplay, setShowFunction, handleSubmit } = this.props;
        return (
            <>

                <div className="formOuter" >
                    <center>
                        <div className="txtContainer">
                            <h4>Welcome Back</h4>
                            <p>Sign in to Continue</p>
                            {setLogin && <div className="clearIcon" onClick={handleLogindisplay}><ClearIcon /></div>}
                            <form onSubmit={handleSubmit}>
                                <TextField id="outlined-basic" value={email} label="Email" variant="outlined" className='LogininputBox' focused required
                                    onChange={handleEmail}
                                />
                                <label className="error" style={{ display: emailError }}>Enter the correct Email-id </label><br />

                                <TextField id="outlined-basic1" value={password} label="Password" variant="outlined" className='LogininputBox' focused required
                                    onChange={handlePass}
                                    type='password'
                                />
                                <label className="error" style={{ display: passwordError }}>Invaild Password</label>

                                <br />
                                <div className="forpass">
                                    <NavLink to='/resetpass' className='p-1'>Forget Password</NavLink>
                                </div>
                                <div className="loginBtn">
                                    <Button variant="contained" color='success' type='submit'>Login</Button>
                                    <Button variant="contained" color='primary'>Login with OTP</Button>
                                </div>
                            </form>

                            <br />
                            <div className="forpass">
                                New to CollegeDekho? <p className='p-1' onClick={setShowFunction}>Signup</p>
                            </div>
                        </div>
                    </center>
                </div>
            </>
        )
    }
}

