import React from 'react';

// import company from './logo1.png'


export default class NewsCard extends React.Component {

  render() {
    return (
      <div className='py-4'>
        <NewsCompany />
      </div>
    )
  }
}


class NewsCompany extends React.Component {
  render() {
    return (
      <>

        <div className="slider">
          <div className="slide-track">
            <LogoImage />
            <LogoImage />
            <LogoImage />
            <LogoImage />
            <LogoImage />
            <LogoImage />
            <LogoImage />
            <LogoImage />
            <LogoImage />
          </div>
        </div>
      </>
    )
  }
}

class LogoImage extends React.Component {
  render() {

    return (
      <>
        <div className="slide">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/557257/2.png" height="100" width="250" alt="" />
        </div>
      </>
    )
  }
}