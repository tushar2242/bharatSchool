import React, { useState, useEffect } from 'react';
import schoollogo from '../../images/logo1.png';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import FmdGoodIcon from '@mui/icons-material/FmdGood';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import StarIcon from '@mui/icons-material/Star';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { NavLink } from 'react-router-dom';

import axios from 'axios';


export default class SchoolCardCarousel extends React.Component {
    render() {
        return (
            <>
                <SchoolCard />
            </>
        )
    }
}


const responsive = {
    superLargeDesktop: {
        breakpoint: { max: 4000, min: 3000 },
        items: 4
    },
    desktop: {
        breakpoint: { max: 3000, min: 1024 },
        items: 4
    },
    tablet: {
        breakpoint: { max: 1024, min: 464 },
        items: 2
    },
    mobile: {
        breakpoint: { max: 464, min: 0 },
        items: 1
    }
};

const SchoolCard = () => {

    const [data, setData] = useState([]);

    useEffect(() => {
        setSchoolData()
    }, [])

    const setSchoolData = () => {
        axios.get('http://localhost:6003/school/find')
            .then((res) => {

                setData(res.data.data)

            })
            .catch(res => console.log(res))
    }


    return (
        <>
            <div className="container-2">
                <div className="IndicatorCarousel">
                    <h1 className="text-center"><b>Recommended <span>School</span> </b></h1>
                    <br></br>
                    <Carousel

                        swipeable={true}
                        draggable={true}
                        showDots={false}
                        responsive={responsive}
                        ssr={true} // means to render carousel on server-side.
                        infinite={true}
                        autoPlay={true}
                        autoPlaySpeed={3000}
                        keyBoardControl={true}
                        //customTransition="all .5"
                        // transitionDuration={700}
                        containerClass="carousel-container"
                        removeArrowOnDeviceType={["desktop", "tablet", "mobile"]}
                    // dotListClass="custom-dot-list-style"
                    // itemClass="carousel-item-padding-40-px"
                    >
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                    </Carousel>
                </div>
            </div>
        </>
    );
};


class Card extends React.Component {
    render() {
        return (
            <>
                <NavLink to='/showSchool' className="IndicatorCarouselCard">
                    <div className="card card-box">
                        <div className="scl-logo-img"><img src={schoollogo} className="img-fluid card-img-top" alt="logo" /></div>
                        <div className="card-body">
                            <hr></hr>
                            <div className="card-view">
                                <h6 className="rev-text"><RemoveRedEyeIcon className="text-success fs-5"></RemoveRedEyeIcon> 50 views</h6>
                                <h6 className="rev-text"><StarIcon className="text-warning fs-5"></StarIcon> rating</h6>
                            </div>
                            <h5 className="school-title">Ghyan Bharti <CheckCircleIcon className="fs-5 text-success"></CheckCircleIcon></h5>
                            <p className="card-text sl-location"> <FmdGoodIcon className="fs-5 text-muted"></FmdGoodIcon> location</p>
                        </div>
                        <div className="ad-open">Admission Open</div>
                    </div>
                </NavLink>
            </>
        )
    }
}