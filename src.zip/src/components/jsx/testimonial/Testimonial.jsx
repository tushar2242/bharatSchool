import React from 'react';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import userimage from '../../images/user.png';


const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 4
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 4
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1
  }
};

const Testimonial = () => {
  return (
    <>
      <div className="container-fluid testimonial">
        <h1 className="text-center"><b>Our <span className="">Testimonials</span></b></h1>
        <div className="IndicatorCarousel">
          <br></br>
          <Carousel

            swipeable={true}
            draggable={true}
            showDots={false}
            responsive={responsive}
            ssr={true} // means to render carousel on server-side.
            infinite={true}
            autoPlay={true}
            autoPlaySpeed={2000}
            keyBoardControl={true}
            removeArrowOnDeviceType={["desktop", "tablet", "mobile"]}
          >
            <div className="IndicatorCarouselCard">
              <TestimonialCard />
            </div>
            <div className="IndicatorCarouselCard">
              <TestimonialCard />
            </div>
            <div className="IndicatorCarouselCard">
              <TestimonialCard />
            </div>
            <div className="IndicatorCarouselCard">
              <TestimonialCard />
            </div>
            <div className="IndicatorCarouselCard">
              <TestimonialCard />
            </div>
          </Carousel>
        </div>
      </div>
    </>
  );
};

export default Testimonial;

class TestimonialCard extends React.Component {
  render() {
    return (
      <>
        <main className="l-card">
          <section className="l-card__text">
            <p>
              This is a comment card appearing above a dotted background, and that's really cool!
            </p>
          </section>
          <section className="l-card__user">
            <div className="l-card__userImage">
              <img src={userimage} alt="Naruto" />
            </div>
            <div className="l-card__userInfo">
              <span>Karan Singh</span>
              <span>Seventh Hokage</span>
            </div>
          </section>
        </main>
      </>
    )
  }
}