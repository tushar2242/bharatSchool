import React from 'react';
import CountUp from 'react-countup';
import schoolicon from '../../images/schoolicon.png';


export default class CounterCard extends React.Component {

    render() {
      return (
        <>
        <div className="counter-bg">
        <div className="container">
            <div className="row">
                <div className="col-md-4 text-center mt-3">
                <SchoolCounter />
                </div>
                <div className="col-md-4 text-center mt-3">
                <SchoolCounter />
                </div>
                <div className="col-md-4 text-center mt-3">
                <SchoolCounter />
                </div>
            </div>
        </div>
        </div>
        </>
      )
    }
}


class SchoolCounter extends React.Component {
    render() {
      return (
        <>
        <div className="d-flex">
            <img src={schoolicon} alt="icon" className="school-icon" />
           <div>
               <CountUp className="counter-font" start={0} end={10000} suffix=" +"></CountUp>
               <h6 className="reg-school ms-3">Registered Schools</h6>
           </div> 
       </div>
        </>
      )
    }
}
