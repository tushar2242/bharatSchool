import TextField from '@mui/material/TextField';
import Checkbox from '@mui/material/Checkbox';
import StarIcon from '@mui/icons-material/Star';

import NavBar from '../navbar/NavBar';
import Footer from '../footer/Footer';
import store from '../../redux/store';
import axios from 'axios';
import Filterschool from './Filterschool';

import React, { useState } from 'react';



// const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

export default class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            searchQuery: '',
            school: []
        }
        this.componentDidMount = this.componentDidMount.bind(this)
        this.searchSchool = this.searchSchool.bind(this);
    }

    componentDidMount() {
        const value = store.getState();
        this.setState({ searchQuery: value })

      
    }

    searchSchool() {
        console.log('f9re')
    }

    render() {
        return (
            <>
                <NavBar
                    loginPopUp={false}
                />

                <div className="filter-display-box">
                    <div className="container mt-4 mb-4">
                        <div className="row">
                            <div className="col-md-3">
                                <Filterbox />
                            </div>
                            <div className="col-md-9">
                                {/* <FilterSchoolCard /> */}
                                <Filterschool />
                            </div>
                        </div>
                    </div>
                </div>
                {/* -----------------------------------For Tablet and Mobile View----------------------------------------------------------- */}
                <div className="tablet-vw-filter">
                    <div className="container">
                        <FilterByBMR>

                        </FilterByBMR>
                        <Filterschool />
                    </div>
                </div>
                <Footer />

            </>
        )
    }
}





class Filterbox extends React.Component {


    render() {
        return (
            <>
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="filter-box mt-3">
                                <h6>FILTER BY BOARD</h6>

                                <div className="filter-scroll">
                                    <SchoolBoard board="CISCE" school="571" />
                                    <SchoolBoard board="CBSE" school="7571" />
                                    <SchoolBoard board="BSEAP" school="5" />
                                    <SchoolBoard board="BSEB" school="1" />
                                    <SchoolBoard board="DBSE" school="0" />
                                </div>
                            </div>

                            <div className="filter-box mt-3">
                                <h6>FILTER BY MEDIUM</h6>

                                <div className="filter-scroll">
                                    <SchoolMedium medium="English" schoolno="6571" />
                                    <SchoolMedium medium="Hindi" schoolno="7571" />
                                    <SchoolMedium medium="Punjabi" schoolno="5" />
                                    <SchoolMedium medium="Bengali" schoolno="1" />
                                    <SchoolMedium medium="Assamese" schoolno="0" />
                                </div>
                            </div>
                            <div className="filter-box mt-3">
                                <h6>FILTER BY RATING</h6>

                                <div className="filter-scroll">
                                    <SchoolRating schoolrating="57" />

                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </>
        )
    }
}


const FilterByBoard = () => {
    return (
        <>
            <div className="filter-box mt-3">
                <h6>FILTER BY BOARD</h6>
                <TextField fullWidth label="Search" margin="normal" size="small" />
                <div className="filter-scroll">
                    <SchoolBoard board="CISCE" school="571" />
                    <SchoolBoard board="CBSE" school="7571" />
                    <SchoolBoard board="BSEAP" school="5" />
                    <SchoolBoard board="BSEB" school="1" />
                    <SchoolBoard board="DBSE" school="0" />
                </div>
            </div>
        </>
    )
}

class SchoolBoard extends React.Component {

    render() {
        return (
            <>

                <div className="d-flex justify-content-between">
                    <div className="d-flex">
                        <Checkbox size="small" />
                        <p className="mt-3 board-font">{this.props.board}</p>
                    </div>
                    <p className="mt-3 board-font">({this.props.school})</p>
                </div>

            </>
        )
    }
}

class SchoolMedium extends React.Component {

    render() {
        return (
            <>

                <div className="d-flex justify-content-between">
                    <div className="d-flex">
                        <Checkbox size="small" />
                        <p className="mt-3 board-font">{this.props.medium}</p>
                    </div>
                    <p className="mt-3 board-font">({this.props.schoolno})</p>
                </div>

            </>
        )
    }
}

class SchoolRating extends React.Component {

    render() {
        return (
            <>

                <div className="d-flex justify-content-between">
                    <div className="d-flex">
                        <Checkbox size="small" />
                        <p className="mt-3 board-font"><StarIcon className="fs-5 text-warning" /> <StarIcon className="fs-5 text-warning" /><StarIcon className="fs-5 text-warning" /><StarIcon className="fs-5 text-warning" /></p>
                    </div>
                    <p className="mt-3 board-font">({this.props.schoolrating})</p>
                </div>

            </>
        )
    }
}


// function TabRes() {
//     const [value, setValue] = React.useState(0);

//     const handleChange = (event: React.SyntheticEvent, newValue: number) => {
//         setValue(newValue);
//     };

//     return (

//         <Tabs
//             value={value}
//             onChange={handleChange}
//             variant="scrollable"
//             scrollButtons={false}
//             aria-label="scrollable prevent tabs example"
//         >
//             <Tab label="Item One" />
//             <Tab label="Item Two" />
//             <Tab label="Item Three" />
//             <Tab label="Item Four" />
//             <Tab label="Item Five" />
//             <Tab label="Item Six" />
//             <Tab label="Item Seven" />
//         </Tabs>
//     );
// }


const FilterByBMR = () => {
    const [filterValue, setFilterValue] = useState('');

    let filterData;

    switch (filterValue) {
        case 'Board':
            filterData = <FilterByBoard />;
            break;
        case 'Medium':
            filterData = <FilterByMedium />;
            break;
        default:
            filterData = <FilterByRating />;
            break;
    }
    return (
        <>
            <div className="filterBmrOuter">
                <div className="filterBtns">
                    <h2 className='my-3'>Filter By : </h2>
                    <ul>
                        <li className="hover-tab" onClick={() => { setFilterValue('Medium') }}>Medium</li>
                        <li className="hover-tab" onClick={() => { setFilterValue('Board') }}>Board</li>
                        <li className="hover-tab" onClick={() => { setFilterValue('Rating') }}>Rating</li>
                    </ul>
                </div>

                <div className="mb-tab-filterData">
                    {filterData}
                </div>
            </div>
        </>
    )
}


const FilterByMedium = () => {
    return (
        <>
            <div className="filter-box mt-3">
                <h6>FILTER BY MEDIUM</h6>
                <TextField fullWidth label="Search" margin="normal" size="small" />
                <div className="filter-scroll">
                    <SchoolMedium medium="English" schoolno="6571" />
                    <SchoolMedium medium="Hindi" schoolno="7571" />
                    <SchoolMedium medium="Punjabi" schoolno="5" />
                    <SchoolMedium medium="Bengali" schoolno="1" />
                    <SchoolMedium medium="Assamese" schoolno="0" />
                </div>
            </div>
        </>
    )
}



const FilterByRating = () => {
    return (
        <>
            <div className="filter-box mt-3">
                <h6>FILTER BY RATING</h6>
                <TextField fullWidth label="Search" margin="normal" size="small" />
                <div className="filter-scroll">
                    <SchoolRating schoolrating="57" />

                </div>
            </div>
        </>
    )
}