// file: src/store.js

import { createStore } from 'redux';
import valueReducer from './valueReducer';

const store = createStore(valueReducer);

export default store;
