// file: src/reducers/valueReducer.js

import { UPDATE_VALUE, UPDATE_VALUE1 } from './valueAction';

export default function valueReducer(state = '', action) {
  switch (action.type) {
    case UPDATE_VALUE:
      return action.payload;
    case UPDATE_VALUE1:
      return action.payload;
    default:
      return state;
  }
}
