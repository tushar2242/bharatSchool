
export const UPDATE_VALUE = 'UPDATE_VALUE';
export const UPDATE_VALUE1 = 'UPDATE_VALUE';

export function updateValue(value) {
  return {
    type: UPDATE_VALUE,
    payload: value,
  };
}

export function updateValue1(data){
  return{
    type:UPDATE_VALUE1,
    payload:data,
  }
}