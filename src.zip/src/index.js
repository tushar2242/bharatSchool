import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import './components/js/AllCss';
import SetRoute from "./components/Routes/SetRoute";
import { Provider } from "react-redux";



const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <BrowserRouter>
    <React.StrictMode>
      <SetRoute />
    </React.StrictMode>
  </BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results 
// or send to an analytics endpoint. Learn more:

